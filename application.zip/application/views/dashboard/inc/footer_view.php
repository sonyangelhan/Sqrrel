		</div>
		<footer>
			&copy; <?=date('Y')?>
		</footer>
	</body>
</html>